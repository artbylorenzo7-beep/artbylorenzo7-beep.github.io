// Bashar's Atelier Console - Identity + Permissions
// Public anon key only. Never place Supabase service_role keys here.

const SUPABASE_URL = 'https://wbcflulqaokpuejvwvyh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiY2ZsdWxxaW9rcHVlanZ3dnloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU5NjE5MjUsImV4cCI6MjEwMTUzNzkyNX0.d-r8Yk386tjBbwdTlX-Pd5-SnTu92e_3GAm24ha_6Nw';

const loginForm=document.getElementById('login-form');
const loginRoom=document.getElementById('login-room');
const consoleRoom=document.getElementById('console-room');
const message=document.getElementById('auth-message');
const logoutButton=document.getElementById('logout');

const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);

const permissions={
 owner:['artworks','journal','exhibition','appearance','access'],
 curator:['artworks','exhibition'],
 editor:['journal']
};

function showConsole(){loginRoom?.classList.add('hidden');consoleRoom?.classList.remove('hidden');}
function showLogin(){loginRoom?.classList.remove('hidden');consoleRoom?.classList.add('hidden');}

async function getProfile(user){
 const {data,error}=await supabaseClient.from('profiles').select('*').eq('id',user.id).single();
 if(error) throw error;
 return data;
}

function applyPermissions(role){
 document.querySelectorAll('[data-room]').forEach(room=>{
   const allowed=(permissions[role]||[]).includes(room.dataset.room);
   room.style.display=allowed?'':'none';
 });
}

async function logActivity(user, action){
 await supabaseClient.from('admin_activity').insert({
   user_id:user.id,
   action,
   metadata:{source:'atelier-console'}
 });
}

async function enter(user){
 const profile=await getProfile(user);
 applyPermissions(profile.role);
 showConsole();
 message.textContent=`Welcome, ${profile.name||'Atelier member'}.`;
 await logActivity(user,'Signed into Atelier Console');
}

loginForm?.addEventListener('submit',async e=>{
 e.preventDefault();
 const email=document.getElementById('email').value;
 const password=document.getElementById('password').value;
 const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});
 if(error){message.textContent=error.message;return;}
 await enter(data.user);
});

logoutButton?.addEventListener('click',async()=>{
 await supabaseClient.auth.signOut();
 showLogin();
});

(async()=>{
 const {data}=await supabaseClient.auth.getSession();
 if(data.session){
   try{await enter(data.session.user);}catch(e){showLogin();}
 }else showLogin();
})();
