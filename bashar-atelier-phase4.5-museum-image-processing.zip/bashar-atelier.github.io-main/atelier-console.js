// Bashar's Atelier Console - Identity + Permissions
// Public anon key only. Never place Supabase service_role keys here.

const SUPABASE_URL = 'https://wbcflulqaokpuejvwvyh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiY2ZsdWxxaW9rcHVlanZ3dnloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU5NjE5MjUsImV4cCI6MjEwMTUzNzkyNX0.d-r8Yk386tjBbwdTlX-Pd5-SnTu92e_3GAm24ha_6Nw';

const loginForm=document.getElementById('login-form');
const loginRoom=document.getElementById('login-room');
const consoleRoom=document.getElementById('console-room');
const message=document.getElementById('auth-message');
const logoutButton=document.getElementById('logout');

const supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);

const permissions={
 owner:['artworks','journal','exhibition','appearance','access'],
 curator:['artworks','exhibition'],
 editor:['journal']
};

function showConsole(){loginRoom?.classList.add('hidden');consoleRoom?.classList.remove('hidden');}
function showLogin(){loginRoom?.classList.remove('hidden');consoleRoom?.classList.add('hidden');}

async function getProfile(user){
 const {data,error}=await supabaseClient.from('profiles').select('*').eq('id',user.id).single();
 if(error) throw error;
 return data;
}

function applyPermissions(role){
 document.querySelectorAll('[data-room]').forEach(room=>{
   const allowed=(permissions[role]||[]).includes(room.dataset.room);
   room.style.display=allowed?'':'none';
 });
}

async function logActivity(user, action){
 await supabaseClient.from('admin_activity').insert({
   user_id:user.id,
   action,
   metadata:{source:'atelier-console'}
 });
}

async function enter(user){
 const profile=await getProfile(user);
 applyPermissions(profile.role);
 showConsole();
 message.textContent=`Welcome, ${profile.name||'Atelier member'}.`;
 await logActivity(user,'Signed into Atelier Console');
}

loginForm?.addEventListener('submit',async e=>{
 e.preventDefault();
 const email=document.getElementById('email').value;
 const password=document.getElementById('password').value;
 const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});
 if(error){message.textContent=error.message;return;}
 await enter(data.user);
});

logoutButton?.addEventListener('click',async()=>{
 await supabaseClient.auth.signOut();
 showLogin();
});

(async()=>{
 const {data}=await supabaseClient.auth.getSession();
 if(data.session){
   try{await enter(data.session.user);}catch(e){showLogin();}
 }else showLogin();
})();


// Phase 4: Real Atelier Console Rooms

async function loadArtworks(){
 const box=document.getElementById('artwork-list');
 if(!box) return;
 const {data,error}=await supabaseClient.from('artworks').select('title,year,medium,published').order('created_at',{ascending:false});
 if(error){box.textContent='Unable to load artworks';return;}
 box.innerHTML=(data||[]).map(a=>`<p>${a.title||'Untitled'} · ${a.year||''} · ${a.published?'Published':'Draft'}</p>`).join('') || '<p>No artworks yet.</p>';
}

async function loadJournal(){
 const box=document.getElementById('journal-list');
 if(!box) return;
 const {data,error}=await supabaseClient.from('journal_posts').select('title,published').order('created_at',{ascending:false});
 if(error){box.textContent='Unable to load journal';return;}
 box.innerHTML=(data||[]).map(p=>`<p>${p.title||'Untitled'} · ${p.published?'Published':'Draft'}</p>`).join('') || '<p>No journal entries yet.</p>';
}

document.getElementById('load-artworks')?.addEventListener('click', loadArtworks);
document.getElementById('load-journal')?.addEventListener('click', loadJournal);


// Phase 4.1 Artwork Vault Full Creation System

const artworkForm = document.getElementById('artwork-form');

artworkForm?.addEventListener('submit', async (event) => {
 event.preventDefault();

 const artwork = {
   title: document.getElementById('art-title').value,
   year: document.getElementById('art-year').value,
   medium: document.getElementById('art-medium').value,
   story: document.getElementById('art-story').value,
   process: document.getElementById('art-process').value,
   featured: document.getElementById('art-featured').checked,
   published: document.getElementById('art-published').checked
 };

 const { error } = await supabaseClient
   .from('artworks')
   .insert([artwork]);

 const message = document.getElementById('auth-message');

 if(error) {
   if(message) message.textContent = 'Artwork could not be saved.';
   console.error(error);
   return;
 }

 if(message) message.textContent = 'Artwork added to the Atelier archive.';
 artworkForm.reset();
});


// Phase 4.2 Advanced Artwork Vault

async function loadAdvancedArtworkVault(){
 const container = document.getElementById('advanced-artwork-list');
 if(!container || !window.supabaseClient) return;

 const {data, error} = await supabaseClient
   .from('artworks')
   .select('id,title,year,medium,published,featured')
   .order('created_at',{ascending:false});

 if(error){
   container.textContent = 'Archive unavailable.';
   return;
 }

 container.innerHTML = (data || []).map(item => `
 <article class="artwork-card">
   <strong>${item.title || 'Untitled'}</strong>
   <p>${item.year || ''} ${item.medium || ''}</p>
   <p>${item.published ? 'Published' : 'Draft'} ${item.featured ? '⭐ Featured' : ''}</p>
   <button data-edit="${item.id}">Edit</button>
   <button data-delete="${item.id}">Archive</button>
 </article>
 `).join('') || '<p>No artworks found.</p>';
}

document.getElementById('refresh-artworks')
?.addEventListener('click', loadAdvancedArtworkVault);

document.getElementById('art-search')
?.addEventListener('input', async (e)=>{
 const query = e.target.value.trim();
 if(!window.supabaseClient) return;
 const {data} = await supabaseClient
   .from('artworks')
   .select('title,year,medium')
   .ilike('title', `%${query}%`);
 const container=document.getElementById('advanced-artwork-list');
 if(container) container.innerHTML=(data||[]).map(a=>`<p>${a.title}</p>`).join('');
});


// Phase 4.3 Professional Artwork Management

const artworkEditForm = document.getElementById('artwork-edit-form');

artworkEditForm?.addEventListener('submit', async (event) => {
 event.preventDefault();

 const id = document.getElementById('edit-art-id').value;

 const updates = {
   image_url: document.getElementById('edit-art-image').value,
   collection: document.getElementById('edit-art-collection').value,
   description: document.getElementById('edit-art-description').value
 };

 const { error } = await supabaseClient
   .from('artworks')
   .update(updates)
   .eq('id', id);

 if(error){
   console.error(error);
   return;
 }

 alert('Artwork updated successfully.');
});

document.getElementById('export-artwork-archive')
?.addEventListener('click', async ()=>{
 const {data,error}=await supabaseClient
   .from('artworks')
   .select('*');

 if(error) return;

 const blob = new Blob([JSON.stringify(data,null,2)], {
   type:'application/json'
 });

 const url = URL.createObjectURL(blob);
 const link = document.createElement('a');
 link.href=url;
 link.download='bashar-atelier-artwork-archive.json';
 link.click();
 URL.revokeObjectURL(url);
});


// Phase 4.4 Image Vault System

const uploadButton = document.getElementById('upload-art-image');

uploadButton?.addEventListener('click', async () => {
 const fileInput = document.getElementById('art-image-upload');
 const status = document.getElementById('upload-status');
 const file = fileInput?.files?.[0];

 if(!file){
   if(status) status.textContent = 'Select an image first.';
   return;
 }

 const safeName = `${Date.now()}-${file.name.replace(/\s+/g,'-')}`;

 const { data, error } = await supabaseClient.storage
   .from('artworks')
   .upload(`originals/${safeName}`, file, {
      cacheControl: '3600',
      upsert: false
   });

 if(error){
   if(status) status.textContent = 'Upload failed.';
   console.error(error);
   return;
 }

 if(status) status.textContent = 'Image stored in Atelier Vault.';
 console.log(data);
});


// Phase 4.5 Museum-Grade Image Processing Foundation

function validateArtworkImage(file){
 const allowed = ['image/jpeg','image/png','image/webp','image/avif'];
 const maxSize = 25 * 1024 * 1024;

 return file &&
        allowed.includes(file.type) &&
        file.size <= maxSize;
}

function createArtworkStoragePath(file){
 const cleanName = file.name
   .toLowerCase()
   .replace(/[^a-z0-9.\-_]/g,'');

 return `originals/${Date.now()}-${cleanName}`;
}

async function prepareArtworkImage(file){
 const status = document.getElementById('image-processing-status');

 if(!validateArtworkImage(file)){
   if(status) status.textContent='Unsupported image or file too large.';
   return null;
 }

 const path = createArtworkStoragePath(file);

 if(status){
   status.textContent =
   'Image validated. Ready for optimized processing pipeline.';
 }

 return path;
}
