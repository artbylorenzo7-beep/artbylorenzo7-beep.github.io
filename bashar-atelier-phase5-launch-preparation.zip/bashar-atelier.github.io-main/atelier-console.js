// Bashar's Atelier Console - Phase 5 Launch Preparation

const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

let supabaseClient = null;
let currentProfile = null;

const loginForm = document.getElementById('login-form');
const loginRoom = document.getElementById('login-room');
const consoleRoom = document.getElementById('console-room');
const message = document.getElementById('auth-message');
const roleLabel = document.getElementById('user-role');

function showConsole(){
 loginRoom?.classList.add('hidden');
 consoleRoom?.classList.remove('hidden');
}

function showLogin(){
 loginRoom?.classList.remove('hidden');
 consoleRoom?.classList.add('hidden');
}

function initSupabase(){
 if(window.supabase && SUPABASE_URL !== 'YOUR_SUPABASE_URL'){
  supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
 }
}

async function loadIdentity(user){
 const {data,error}=await supabaseClient
  .from('profiles')
  .select('role')
  .eq('id',user.id)
  .single();

 if(error || !data){
  message.textContent='No Atelier profile found.';
  await supabaseClient.auth.signOut();
  return false;
 }

 currentProfile=data;
 roleLabel.textContent=`Role: ${data.role}`;
 applyPermissions(data.role);

 await logActivity('login');
 return true;
}

function applyPermissions(role){
 document.querySelectorAll('.rooms article').forEach(room=>{
  const allowed=(room.dataset.role||'').split(',');
  room.style.display=allowed.includes(role)?'block':'none';
 });
}

async function logActivity(action){
 if(!supabaseClient) return;
 await supabaseClient.from('admin_activity').insert({
  action,
  metadata:{source:'atelier-console'}
 });
}

loginForm?.addEventListener('submit',async(e)=>{
 e.preventDefault();
 if(!supabaseClient){
  message.textContent='Supabase connection is not configured.';
  return;
 }
 const email=document.getElementById('email').value;
 const password=document.getElementById('password').value;
 const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});
 if(error){message.textContent=error.message;return;}
 if(await loadIdentity(data.user)) showConsole();
});

document.getElementById('logout')?.addEventListener('click',async()=>{
 await logActivity('logout');
 await supabaseClient?.auth.signOut();
 currentProfile=null;
 showLogin();
});

async function boot(){
 initSupabase();
 if(!supabaseClient){showLogin();return;}
 const {data}=await supabaseClient.auth.getSession();
 if(data.session && await loadIdentity(data.session.user)) showConsole();
 else showLogin();
}

boot();
